package BlueboxPack;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class blueTrack {
    private int iD;
    private int iTmId;
    private String location;
    private String dateOut;
    private String dateBack;
    private int qunt;
    private boolean alert;
    private String aCtionNote;

    public blueTrack(int iD, int iTmId, String location, String dateOut, String dateBack, int qunt, boolean alert, String aCtionNote) {
        this.iD = iD;
        this.iTmId = iTmId;
        this.location = location;
        this.dateOut = dateOut;
        this.dateBack = dateBack;
        this.qunt = qunt;
        this.alert = alert;
        this.aCtionNote = aCtionNote;
    }

    public int getiD() {
        return iD;
    }

    public void setiD(int iD) {
        this.iD = iD;
    }

    public int getiTmId() {
        return iTmId;
    }

    public void setiTmId(int iTmId) {
        this.iTmId = iTmId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDateOut() {
        return dateOut;
    }

    public void setDateOut(String dateOut) {
        this.dateOut = dateOut;
    }

    public String getDateBack() {
        return dateBack;
    }

    public void setDateBack(String dateBack) {
        this.dateBack = dateBack;
    }

    public int getQunt() {
        return qunt;
    }

    public void setQunt(int qunt) {
        this.qunt = qunt;
    }

    public boolean isAlert() {
        return alert;
    }

    public void setAlert(boolean alert) {
        this.alert = alert;
    }

    public String getaCtionNote() {
        return aCtionNote;
    }

    public void setaCtionNote(String aCtionNote) {
        this.aCtionNote = aCtionNote;
    }

    
    
}
