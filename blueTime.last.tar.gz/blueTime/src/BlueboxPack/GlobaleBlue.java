package BlueboxPack;

import javax.swing.JList;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class GlobaleBlue {
    static int iTemsId = 0;
    static int trackId = 0;
    static int eventId = 0;
    static int tickId = 0;
    static int itemQtAdd = 1;
    static String EventItemC = null;
    static String Brandc = null;
    static String[] brandL;
    static String Kindc = null;
    static String[] kindL;
    static String Itemc = null;
    static String[] itemL;
    static String tickAdmin = null;
    static String NameUser = null;
    static String[] locations;

    public GlobaleBlue() {
    }

    public static int getiTemsId() {
        return iTemsId;
    }

    public static void setiTemsId(int iTemsId) {
        GlobaleBlue.iTemsId = iTemsId;
    }

    public static int getTrackId() {
        return trackId;
    }

    public static void setTrackId(int trackId) {
        GlobaleBlue.trackId = trackId;
    }

    public static int getEventId() {
        return eventId;
    }

    public static void setEventId(int eventId) {
        GlobaleBlue.eventId = eventId;
    }

    public static int getTickId() {
        return tickId;
    }

    public static void setTickId(int tickId) {
        GlobaleBlue.tickId = tickId;
    }

    public static int getItemQtAdd() {
        return itemQtAdd;
    }

    public static void setItemQtAdd(int itemQtAdd) {
        GlobaleBlue.itemQtAdd = itemQtAdd;
    }

    public static String getBrandc() {
        return Brandc;
    }

    public static void setBrandc(String Brandc) {
        GlobaleBlue.Brandc = Brandc;
    }

    public static String[] getBrandL() {
        return brandL;
    }

    public static void setBrandL(String[] brandL) {
        GlobaleBlue.brandL = brandL;
    }

    public static String getKindc() {
        return Kindc;
    }

    public static void setKindc(String Kindc) {
        GlobaleBlue.Kindc = Kindc;
    }

    public static String[] getKindL() {
        return kindL;
    }

    public static void setKindL(String[] kindL) {
        GlobaleBlue.kindL = kindL;
    }

    public static String getItemc() {
        return Itemc;
    }

    public static void setItemc(String Itemc) {
        GlobaleBlue.Itemc = Itemc;
    }

    public static String[] getItemL() {
        return itemL;
    }

    public static void setItemL(String[] itemL) {
        GlobaleBlue.itemL = itemL;
    }

    public static String getTickAdmin() {
        return tickAdmin;
    }

    public static void setTickAdmin(String tickAdmin) {
        GlobaleBlue.tickAdmin = tickAdmin;
    }

    public static String getNameUser() {
        return NameUser;
    }

    public static void setNameUser(String NameUser) {
        GlobaleBlue.NameUser = NameUser;
    }

    public static String[] getLocations() {
        return locations;
    }

    public static void setLocations(String[] locations) {
        GlobaleBlue.locations = locations;
    }
    
    public static void main(String[] args)
    {
        
    }
    
}
