package BlueboxPack;

import com.mysql.cj.protocol.Resultset;
import com.toedter.calendar.JDateChooser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.MenuSelectionManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class storageF extends javax.swing.JFrame {

    
    public storageF() {
        initComponents();
        populateJtableItem();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel9 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jTFiD = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTFkInd = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTFiTem = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTFmOdel = new javax.swing.JTextField();
        jTFbRand = new javax.swing.JTextField();
        jTFqNty = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        BTNrefresh = new javax.swing.JButton();
        BTNaddItem = new javax.swing.JButton();
        BTNdeleteItem = new javax.swing.JButton();
        BTNeDit = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jTFlOcation = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jTFcount = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTabletTrack = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTAnOte = new javax.swing.JTextArea();
        jLabel21 = new javax.swing.JLabel();
        BTNmOve = new javax.swing.JButton();
        jTFdAteOuT = new javax.swing.JTextField();
        jTFdAteBaCk = new javax.swing.JTextField();
        BTNclearTrack = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableItems = new javax.swing.JTable();
        BTNmainMenu = new javax.swing.JButton();
        jLabeluserName = new javax.swing.JLabel();

        jPanel9.setBackground(java.awt.Color.lightGray);
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Maintenance"));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 83, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Storage");
        setBackground(java.awt.Color.lightGray);

        jPanel13.setBackground(java.awt.Color.lightGray);
        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Storage"));

        jPanel5.setBackground(java.awt.Color.lightGray);
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Item:قطع"));

        jLabel1.setText("رقم :");

        jLabel2.setText("iD :");

        jLabel3.setText("Kind :");

        jLabel4.setText("النوع :");

        jLabel5.setText("القطعة :");

        jLabel6.setText("Item :");

        jLabel7.setText("Model :");

        jLabel8.setText("التصنيف :");

        jLabel9.setText("Brand :");

        jLabel10.setText("الماركة :");

        jLabel11.setText("Total Count :");

        jLabel12.setText("العدد الكلي :");

        BTNrefresh.setText("ReFresh");
        BTNrefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNrefreshActionPerformed(evt);
            }
        });

        BTNaddItem.setText("Add");
        BTNaddItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNaddItemActionPerformed(evt);
            }
        });

        BTNdeleteItem.setText("Delete");
        BTNdeleteItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNdeleteItemActionPerformed(evt);
            }
        });

        BTNeDit.setText("Edit");
        BTNeDit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNeDitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFiD)
                            .addComponent(jTFkInd, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTFbRand)
                            .addComponent(jTFmOdel, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTFqNty)
                            .addComponent(jTFiTem, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(BTNrefresh)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BTNaddItem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addComponent(BTNeDit)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BTNdeleteItem, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFiD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTFkInd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFiTem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTFmOdel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFbRand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFqNty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTNrefresh)
                    .addComponent(BTNaddItem)
                    .addComponent(BTNdeleteItem)
                    .addComponent(BTNeDit))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBackground(java.awt.Color.lightGray);
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "track:متابعة"));

        jLabel13.setText("Location :");

        jLabel14.setText("الموقع :");

        jLabel15.setText("تاريخ الخروج :");

        jLabel16.setText("تاريخ الرجوع :");

        jLabel17.setText("Date Out :");

        jLabel18.setText("Date Back :");

        jLabel19.setText("count :");

        jLabel20.setText("عدد :");

        jPanel7.setBackground(new java.awt.Color(0, 0, 0));
        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTabletTrack.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Location", "Quntity", "Date Out", "Date Back", "Note"
            }
        ));
        jTabletTrack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabletTrackMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTabletTrack);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTAnOte.setColumns(20);
        jTAnOte.setRows(5);
        jScrollPane3.setViewportView(jTAnOte);

        jLabel21.setText("Track :");

        BTNmOve.setText("Add track");
        BTNmOve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNmOveActionPerformed(evt);
            }
        });

        jTFdAteOuT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFdAteOuTActionPerformed(evt);
            }
        });

        BTNclearTrack.setText("Clear");
        BTNclearTrack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNclearTrackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel19)
                                            .addComponent(jLabel13)))
                                    .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTFcount)
                                    .addComponent(jTFlOcation)
                                    .addComponent(jTFdAteOuT, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel18)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTFdAteBaCk, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(jLabel20)
                            .addComponent(jLabel16))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel21)
                                .addGap(80, 80, 80)
                                .addComponent(BTNclearTrack)
                                .addGap(18, 18, 18)
                                .addComponent(BTNmOve))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(jTFlOcation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTFcount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel20))
                            .addComponent(jLabel19))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel17)
                                    .addComponent(jTFdAteOuT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel18)
                                    .addComponent(jTFdAteBaCk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel16)))
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14)
                        .addComponent(jLabel21))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BTNmOve)
                            .addComponent(BTNclearTrack))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)))
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTableItems.setBackground(java.awt.Color.lightGray);
        jTableItems.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTableItems.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "iD", "Kind", "Item", "Model", "Brand", "Qnty"
            }
        ));
        jTableItems.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableItemsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableItems);

        BTNmainMenu.setText("Back to Main Menu");
        BTNmainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNmainMenuActionPerformed(evt);
            }
        });

        jLabeluserName.setText(GlobaleBlue.NameUser);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabeluserName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BTNmainMenu)))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BTNmainMenu))
                    .addComponent(jLabeluserName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTableItemsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableItemsMouseClicked
        int IId = 0;
        GlobaleBlue.iTemsId = IId;
        int rowIndex = jTableItems.getSelectedRow();
        jTFiD.setText((String) jTableItems.getValueAt(rowIndex, 0).toString());
        GlobaleBlue.iTemsId = Integer.valueOf(jTFiD.getText());
        itemHas(GlobaleBlue.iTemsId);
        jTFkInd.setText((String) jTableItems.getValueAt(rowIndex, 1).toString());
        jTFiTem.setText((String) jTableItems.getValueAt(rowIndex, 2).toString());
        jTFmOdel.setText((String) jTableItems.getValueAt(rowIndex, 3).toString());
        jTFbRand.setText((String) jTableItems.getValueAt(rowIndex, 4).toString());
        jTFqNty.setText((String) jTableItems.getValueAt(rowIndex, 5).toString());
    }//GEN-LAST:event_jTableItemsMouseClicked

    private void BTNclearTrackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNclearTrackActionPerformed
        trackClr();
    }//GEN-LAST:event_BTNclearTrackActionPerformed

    private void jTFdAteOuTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFdAteOuTActionPerformed

    }//GEN-LAST:event_jTFdAteOuTActionPerformed

    private void BTNmOveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNmOveActionPerformed
        int iD = 0;
        int itemIdD = GlobaleBlue.iTemsId;
        String location = jTFlOcation.getText();
        String date_out = jTFdAteOuT.getText();
        String date_back = jTFdAteBaCk.getText();
        int qunt = Integer.valueOf(jTFcount.getText());
        boolean alert = true;
        String noTe = jTAnOte.getText();
        blueTrack tR = new blueTrack( iD, itemIdD, location, date_out, date_back, qunt, alert, noTe);
        blueQuery Tr = new blueQuery();
        Tr.createHistory(tR);
    }//GEN-LAST:event_BTNmOveActionPerformed

    private void jTabletTrackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabletTrackMouseClicked
        boolean cliCKs = true;
        int rowIndex = jTabletTrack.getSelectedRow();
        GlobaleBlue.trackId = jTabletTrack.getValueAt(rowIndex, 0).hashCode();
        if(cliCKs == true)
        System.out.println(GlobaleBlue.trackId);
        rfFreSHTrackF();
        Connection con = BlurConnction.getConnection();
        PreparedStatement Ps;
        ResultSet Rs;
        try {
            Ps = con.prepareStatement("SELECT `iD`, `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack` WHERE `iD` = ?");
            Ps.setInt(1, GlobaleBlue.trackId);
            Rs = Ps.executeQuery();
            if(Rs.next())
            {
                blueQuery tQt = new blueQuery();
                ArrayList<blueTrack> ctQList = tQt.trList();
                String[] colNames = {"iD","Location","qunt","dateOut","dateBack","action_note"};
                Object[][] rows = new Object[ctQList.size()][6];
                for(int i = 0; i < 1; i++)
                {
                    rows[i][0] = ctQList.get(i).getiD();
                    System.out.println(ctQList.get(i).getiD());
                    GlobaleBlue.trackId = ctQList.get(i).getiD();
                    rows[i][1] = ctQList.get(i).getLocation();
                    System.out.println(ctQList.get(i).getLocation());
                    jTFlOcation.setText(ctQList.get(i).getLocation());
                    rows[i][2] = ctQList.get(i).getQunt();
                    System.out.println(ctQList.get(i).getQunt());
                    int count = Integer.valueOf(ctQList.get(i).getQunt());// convert object to int
                    String QqQ = String.valueOf(count);// convert int to String
                    jTFcount.setText(QqQ);
                    rows[i][3] = ctQList.get(i).getDateOut();
                    System.out.println(ctQList.get(i).getDateOut());
                    jTFdAteOuT.setText(ctQList.get(i).getDateOut());
                    rows[i][4] = ctQList.get(i).getDateBack();
                    System.out.println(ctQList.get(i).getDateBack());
                    jTFdAteBaCk.setText(ctQList.get(i).getDateBack());
                    rows[i][5] = ctQList.get(i).getaCtionNote();
                    System.out.println(ctQList.get(i).getaCtionNote());
                    jTAnOte.setText(ctQList.get(i).getaCtionNote());
                }
                System.out.println(GlobaleBlue.iTemsId + " itemId : TrackId :" + GlobaleBlue.trackId);
            }
        } catch (SQLException ex) {
            Logger.getLogger(storageF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jTabletTrackMouseClicked

    private void BTNeDitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNeDitActionPerformed
        int iD = Integer.valueOf(jTFiD.getText());
        String kind = jTFkInd.getText();
        String iTem = jTFiTem.getText();
        String tipss = jTFmOdel.getText();
        String bran = jTFbRand.getText();
        int tot = Integer.valueOf(jTFqNty.getText());
        if(GlobaleBlue.iTemsId != 0)
        {
            System.out.println("|____ : " + GlobaleBlue.iTemsId);
            System.out.println("|__ : '" + iD + "' :" + kind + " _ " + iTem + " _ " + tipss + " - " + bran + " : " + tot + " total.");
            blueItem e = new blueItem(iD, kind, iTem, tipss, bran, tot);
            blueQuery eE = new blueQuery();
            eE.editItem(e);
            populateJtableItem();
        }
    }//GEN-LAST:event_BTNeDitActionPerformed

    private void BTNdeleteItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNdeleteItemActionPerformed
        int Id = Integer.valueOf(jTFiD.getText());
        blueQuery dQ = new blueQuery();
        int confirmed = JOptionPane.showConfirmDialog(null, "Are you sure!. you want to permanently delete this item?",
                "Deleting Item:", JOptionPane.YES_NO_OPTION);
        
        if (confirmed == JOptionPane.YES_OPTION)
        {
            dQ.deletItm(Id);
            populateJtableItem();
        }
    }//GEN-LAST:event_BTNdeleteItemActionPerformed

    private void BTNaddItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNaddItemActionPerformed
        String kInd = jTFkInd.getText();
        String iTem = jTFiTem.getText();
        String tYpes = jTFmOdel.getText();
        String bRand = jTFbRand.getText();
        int qNty = Integer.valueOf(jTFqNty.getText());
        blueItem aI = new blueItem( 0 , kInd, iTem, tYpes, bRand, qNty);
        blueQuery Ai = new blueQuery();
        Ai.insertItem(aI);
        populateJtableItem();
    }//GEN-LAST:event_BTNaddItemActionPerformed

    private void BTNrefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNrefreshActionPerformed
        populateJtableItem();
        jTFiD.setText(null);
        jTFkInd.setText(null);
        jTFiTem.setText(null);
        jTFmOdel.setText(null);
        jTFbRand.setText(null);
        jTFqNty.setText(null);
    }//GEN-LAST:event_BTNrefreshActionPerformed

    private void BTNmainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNmainMenuActionPerformed
        naVi CfM = new naVi();
        CfM.setVisible(true);
        CfM.pack();
        CfM.setLocationRelativeTo(null);
        CfM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_BTNmainMenuActionPerformed

    public boolean itemHas(int It)
    {
        boolean iHy = false;
        Connection con = BlurConnction.getConnection();
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = con.prepareCall("SELECT `iD`, `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack` WHERE `item_id` = ?");
            ps.setInt(1, It);
            rs = ps.executeQuery();
            if(rs.next())
            {
                iHy = true;
                blueQuery tQ = new blueQuery();
                ArrayList<blueTrack> tQList = tQ.bltrList();
                String[] colNames = {"Record ID","location","dateOut","dateBack", "qunt", "action_note"};
                Object[][] rows = new Object[tQList.size()][6];
                for(int i = 0; i < tQList.size(); i++)
                {
                    rows[i][0] = tQList.get(i).getiD();
                    rows[i][1] = tQList.get(i).getLocation();
                    rows[i][2] = tQList.get(i).getDateOut();
                    rows[i][3] = tQList.get(i).getDateBack();
                    rows[i][4] = tQList.get(i).getQunt();
                    rows[i][5] = tQList.get(i).getaCtionNote();
                }
                System.out.println(GlobaleBlue.trackId + " :From iH! on Storage");
                DefaultTableModel JmT = new DefaultTableModel(rows, colNames);
                jTabletTrack.setModel(JmT);
            }
            else 
            {
                iHy = false;
                trackClr();
            }
        } catch (SQLException ex) {
            Logger.getLogger(storageF.class.getName()).log(Level.SEVERE, null, ex);
        }
        return iHy;
    }
    
    
    
    /**
     * this method to populate items table "blueItem Class"
     * 
     * <p>
     * return an Arraylist of date to fill the Jtable.
     * 
     * @return 
     */
    public void populateJtableItem()
    {
        blueQuery iQ = new blueQuery();
        ArrayList<blueItem> iTmAList = iQ.iTList();
        String[] colNames = {"ID","Kind","Item","Type","Brand","quantity"};
        Object[][] rows = new Object[iTmAList.size()][6];
        for(int i = 0; i < iTmAList.size(); i++)
        {
            rows[i][0] = iTmAList.get(i).getiD();
            rows[i][1] = iTmAList.get(i).getkInd();
            rows[i][2] = iTmAList.get(i).getiTem();
            rows[i][3] = iTmAList.get(i).gettYpes();
            rows[i][4] = iTmAList.get(i).getbRand();
            rows[i][5] = iTmAList.get(i).getqNty();
        }
        DefaultTableModel itmT = new DefaultTableModel(rows, colNames);
        jTableItems.setModel(itmT);
    }
    
    /**
     * this method is to clear the track fields.
     */
    public void rfFreSHTrackF()
    {
        jTFcount.setText(null);
        jTFlOcation.setText(null);
        jTFdAteBaCk.setText(null);
        jTFdAteOuT.setText(null);
        jTAnOte.setText(null);
    }
    /**
     * this method is to clear 
     * track item clear table and fileds.
     */
    public void trackClr()
    {
        rfFreSHTrackF();
        String[] colNames = {"Record ID","location", "qunt","dateOut","dateBack","action_note"};
        int rows = 0;
        DefaultTableModel itTc = new DefaultTableModel(colNames, rows);
        jTabletTrack.setModel(itTc);
    }
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(storageF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(storageF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(storageF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(storageF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new storageF().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNaddItem;
    private javax.swing.JButton BTNclearTrack;
    private javax.swing.JButton BTNdeleteItem;
    private javax.swing.JButton BTNeDit;
    private javax.swing.JButton BTNmOve;
    private javax.swing.JButton BTNmainMenu;
    private javax.swing.JButton BTNrefresh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    public javax.swing.JLabel jLabeluserName;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTAnOte;
    private javax.swing.JTextField jTFbRand;
    private javax.swing.JTextField jTFcount;
    private javax.swing.JTextField jTFdAteBaCk;
    private javax.swing.JTextField jTFdAteOuT;
    private javax.swing.JTextField jTFiD;
    private javax.swing.JTextField jTFiTem;
    private javax.swing.JTextField jTFkInd;
    private javax.swing.JTextField jTFlOcation;
    private javax.swing.JTextField jTFmOdel;
    private javax.swing.JTextField jTFqNty;
    private javax.swing.JTable jTableItems;
    private javax.swing.JTable jTabletTrack;
    // End of variables declaration//GEN-END:variables

}
