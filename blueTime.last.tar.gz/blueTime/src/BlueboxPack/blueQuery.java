package BlueboxPack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jdk.nashorn.internal.objects.Global;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class blueQuery {
    
    
    public ArrayList<blueItem> iTList()
    {
        ArrayList<blueItem> iAList = new ArrayList<blueItem>();
        Connection con = BlurConnction.getConnection();
        Statement st;
        ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery("SELECT `ID`, `kind`, `item`, `types`, `brand`, `quantity` FROM `Sitems`");
            while(rs.next())
            {
                blueItem iAl = new blueItem(
                        rs.getInt("iD"),
                        rs.getString("kind"),
                        rs.getString("item"),
                        rs.getString("types"),
                        rs.getString("brand"),
                        rs.getInt("quantity")
                );
                iAList.add(iAl);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return iAList;
    }
    
    
    //insert to Sitems table in the Db
    public boolean insertItem(blueItem iteM)
    {
        boolean itemInserted = true;
        Connection con = BlurConnction.getConnection();
        PreparedStatement pS;
        try {
            pS = con.prepareStatement("INSERT INTO `Sitems`(`kind`, `item`, `types`, `brand`, `quantity`) VALUES (?,?,?,?,?)");
            pS.setString(1, iteM.getkInd());
            pS.setString(2, iteM.getiTem());
            pS.setString(3, iteM.gettYpes());
            pS.setString(4, iteM.getbRand());
            pS.setInt(5, iteM.getqNty());
            if(pS.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "New Item Added!");
                itemInserted = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Error 110 Insert");
                itemInserted = false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return itemInserted;
    }
    
    //Update item
    //UPDATE `Sitems` SET `types` = '-Olk' WHERE `Sitems`.`ID` = 3;
    //SELECT `ID`, `kind`, `item`, `types`, `brand`, `quantity` FROM `Sitems` WHERE 1
    
    /**
     * Updates the item selected record.
     * <p>
     * Updates the item selected record.
     * @param idE 
     * @return 
     */
    public void editItem(blueItem idE)
    {
        Connection con = BlurConnction.getConnection();
        PreparedStatement Psu;
        String upDQuery = "";
        if(idE != null)
        {
            upDQuery = "UPDATE `Sitems` SET kind = ?, item = ?, types = ?, brand = ?, quantity = ?  WHERE Sitems . ID = ?";
            try {
                    Psu = con.prepareStatement(upDQuery);
                    Psu.setString(1, idE.getkInd());
                    Psu.setString(2, idE.getiTem());
                    Psu.setString(3, idE.gettYpes());
                    Psu.setString(4, idE.getbRand());
                    Psu.setInt(5, idE.getqNty());
                    Psu.setInt(6, GlobaleBlue.iTemsId);
                    if(Psu.executeUpdate() != 0)
                    {
                        JOptionPane.showMessageDialog(null, " |_ " + idE.getiD() + " Edited");
                    }
            } catch (SQLException ex) {
                Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            System.out.println("Ok___ error 20099");
            try {
                    Psu = con.prepareStatement(upDQuery);
                    Psu.setString(1, idE.getkInd());
                    Psu.setString(2, idE.getiTem());
                    Psu.setString(3, idE.gettYpes());
                    Psu.setString(4, idE.getbRand());
                    Psu.setInt(5, idE.getqNty());
                    if(Psu.executeUpdate() != 0)
                    {
                        JOptionPane.showMessageDialog(null, " |_ " + idE.getiD() + " Edited");
                    }
            } catch (SQLException ex) {
                Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
    //Delete Item 
    public void deletItm(int idM)
    {
        Connection con = BlurConnction.getConnection();
        PreparedStatement pS;
        try {
            pS = con.prepareStatement("DELETE FROM `Sitems` WHERE `ID` = ?");
            pS.setInt(1, idM);
            if(pS.executeUpdate() != 0) 
            {
                JOptionPane.showMessageDialog(null, "Item is Deleted!");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Error 113 Delete");
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * taks a String username to find it in the user table to delete it.
     * <p>
     * this method to delete a user from user table.
     * 
     * @param username user name String.
     * @return 
     */
    public void deletUser(String uName)
    {
        Connection con = BlurConnction.getConnection();
        PreparedStatement pS;
        try {
            pS = con.prepareStatement("DELETE FROM `user` WHERE `username` = ?");
            pS.setString(1, uName);
            if(pS.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "User :" + uName + " Deleted-");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Error -- 1190");
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    //history table array List
    public ArrayList<blueTrack> trList()
    {
        ArrayList<blueTrack> tcList = new ArrayList<blueTrack>();
        Connection con = BlurConnction.getConnection();
        PreparedStatement ps;
        ResultSet rS;
        try {
            ps = con.prepareStatement("SELECT  `iD`, `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack` WHERE `iD` = ?");
            ps.setInt(1, GlobaleBlue.trackId);
            rS = ps.executeQuery();
            while(rS.next())
            {
                blueTrack tAt = new blueTrack(rS.getInt("iD"),
                        rS.getInt("item_id"),
                        rS.getString("location"),
                        rS.getString("date_out"),
                        rS.getString("date_back"),
                        rS.getInt("qunt"),
                        rS.getBoolean("alert"),
                        rS.getString("action_note")
                );
                GlobaleBlue.trackId = rS.getInt("iD");
                System.out.println(GlobaleBlue.trackId + "  : fromtr");
                tcList.add(tAt);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tcList;
    }
    
    //track hestory item::
    public ArrayList<blueTrack> bltrList()
    {
        ArrayList<blueTrack> btList = new ArrayList<blueTrack>();
        Connection con = BlurConnction.getConnection();
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = con.prepareStatement("SELECT  `iD`, `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack` WHERE `item_id` = ?");
            ps.setInt(1, GlobaleBlue.iTemsId);
            rs = ps.executeQuery();
            while(rs.next())
            {
                blueTrack btH = new blueTrack(rs.getInt("iD"),
                        rs.getInt("item_id"),
                        rs.getString("location"),
                        rs.getString("date_out"),
                        rs.getString("date_back"),
                        rs.getInt("qunt"),
                        rs.getBoolean("alert"),
                        rs.getString("action_note"));
                GlobaleBlue.trackId = rs.getInt("iD");
                btList.add(btH);
            }
            
            System.out.println(GlobaleBlue.trackId + "  : from bltr");
        } 
        catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return btList;
    }
    
    //insert in to tack table::
    //INSERT INTO `Ttrack` (`iD`, `item_id`, `location`, `time`, `date_out`, `date_back`, `qunt`, `alert`, `action_note`) VALUES (NULL, '8', 'الزهراء', CURRENT_TIMESTAMP, '2021-09-25', '2021-09-29', '2', '1', 'فثسفهىل 123');
    public boolean createHistory(blueTrack hiy)
    {
        boolean itmhistory = true;
        Connection con = BlurConnction.getConnection();
        PreparedStatement ps;
        try {
            ps = con.prepareStatement("INSERT INTO `Ttrack` (`iD`, `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note`) VALUES (?,?,?,?,?,?,?,?)");
            ps.setInt(1, hiy.getiD());
            ps.setInt(2, hiy.getiTmId());
            ps.setString(3, hiy.getLocation());
            ps.setString(4, hiy.getDateOut()); // getDateOut()
            ps.setString(5, hiy.getDateBack()); // getDateBack()
            ps.setInt(6, hiy.getQunt());
            ps.setBoolean(7, hiy.isAlert());
            ps.setString(8, hiy.getaCtionNote());
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "History Created for item :" + GlobaleBlue.iTemsId);
                itmhistory = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "no new record for item :" + GlobaleBlue.iTemsId);
                itmhistory = false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return itmhistory;
    }
    
    /**
     * Returns an array list of users that been created
     * <p>
     * this methos returns user list in an Array.
     * 
     * @return 
     */
    public ArrayList<BlueUser> uSList()
    {
        ArrayList<BlueUser> urList = new ArrayList<BlueUser>();
        Connection con = BlurConnction.getConnection();
        Statement uSt;
        ResultSet uRs;
        try {
            uSt = con.createStatement();
            uRs = uSt.executeQuery("SELECT * from user");
            while(uRs.next())
            {
                BlueUser iLuser = new BlueUser(
                        uRs.getString("fname"),
                        uRs.getString("lname"),
                        uRs.getString("username"),
                        uRs.getString("pass"));
                urList.add(iLuser);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return urList;
    }
    
    /**
     * method for adding new record in event.
     * <p>
     * 
     * @return
     */
    public boolean recordIncert(mrePo nis)
    {
        boolean recordI = true;
        Connection con = BlurConnction.getConnection();
        PreparedStatement ps;
        try {
            ps = con.prepareCall("INSERT INTO `main_repo`(`item`, `location`, `date_in`, `date_out`, `user_local`, `end_user_audio`, `end_user_light`, `end_user_video`, `end_user_reging`, `end_user_general`, `end_user_E_elecrission`, `end_user_E_events`, `initial_ticket_text`, `report_action`, `local_reeport`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, nis.getItem());
            ps.setString(2, nis.getLocation());
            ps.setString(3, nis.getDate_in());
            ps.setString(4, nis.getDate_out());
            ps.setString(5, nis.getUser_local());
            //ps.setString(6, nis.getExecution_date());
            ps.setString(7, nis.getEnd_user_audio());
            ps.setString(8, nis.getEnd_user_light());
            ps.setString(9, nis.getEnd_user_video());
            ps.setString(10, nis.getEnd_user_reging());
            ps.setString(11, nis.getEnd_user_general());
            ps.setString(12, nis.getEnd_user_E_elecrission());
            ps.setString(13, nis.getEnd_user_E_events());
            ps.setString(14, nis.getInitial_ticket_text());
            ps.setString(15, nis.getReport_action());
            ps.setString(16, nis.getLocal_reeport());
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "New record inserted!");
                recordI = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Error -0008");
                recordI = false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return recordI;
    }
}
