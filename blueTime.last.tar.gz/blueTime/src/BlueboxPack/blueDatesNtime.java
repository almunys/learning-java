package BlueboxPack;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Khaled Almunys developer for bluebox
 *
 * 		String dateValue = Dblue;
 * 		java.util.Date date = new SimpleDateFormat("MM-dd-yyyy").parse(dateValue);
*/
public class blueDatesNtime {
    String Dblue;
//    Object Dblue;
    

//    public blueDatesNtime(String Dblue) {
//        this.Dblue = Dblue;
//        try {
//            java.util.Date date = new SimpleDateFormat("MM-dd-yyyy").parse(Dblue);
//        } catch (ParseException ex) {
//            Logger.getLogger(blueDatesNtime.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }

    public blueDatesNtime(String Dblue) {
        try {
            java.util.Date date = new SimpleDateFormat("MM-dd-yyyy").parse(Dblue);
        } catch (ParseException ex) {
            Logger.getLogger(blueDatesNtime.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.Dblue = Dblue;
    }

    public String getDblue() {
        try {
            java.util.Date date = new SimpleDateFormat("MM-dd-yyyy").parse(Dblue);
        } catch (ParseException ex) {
            Logger.getLogger(blueDatesNtime.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Dblue;
    }

    public void setDblue(String Dblue) {
        try {
            java.util.Date date = new SimpleDateFormat("MM-dd-yyyy").parse(Dblue);
        } catch (ParseException ex) {
            Logger.getLogger(blueDatesNtime.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.Dblue = Dblue;
    }
    
    
}
