package BlueboxPack;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Khaled Almunys developer for bluebox
 * @param fName for first name lName for last name uSerName for username pAssword for Pass
 */
public class BlueUser {
    private int iD;
    private String fname;
    private String lname;
    private String username;
    private String pass;

    public BlueUser() {
    }
//    BlueUser(Integer iD, String fname, String lname, String username, String pass) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    public BlueUser(int iD, String fname, String lname, String username, String pass) {
        this.iD = iD;
        this.fname = fname;
        this.lname = lname;
        this.username = username;
        this.pass = pass;
    }

    public BlueUser(String fname, String lname, String username) {
        this.fname = fname;
        this.lname = lname;
        this.username = username;
    }

    
    BlueUser(String string, String string0, String string1, String string2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

//    BlueUser(String fname, String lname, String username, String pass) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    public int getiD() {
        return iD;
    }

    public void setiD(int iD) {
        this.iD = iD;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    

    //user ArrayList Ulisk
    public ArrayList<BlueUser> ulk()
    {

        ArrayList<BlueUser> urLp = new ArrayList<BlueUser>();
        Connection con = BlurConnction.getConnection();
        Statement uSt;
        ResultSet uRs;
        try {
            uSt = con.createStatement();
            uRs = uSt.executeQuery("SELECT * from user");
            while(uRs.next())
            {
                BlueUser iLuser = new BlueUser(
                        uRs.getInt("iD"),
                        uRs.getString("fname"),
                        uRs.getString("lname"),
                        uRs.getString("username"),
                        uRs.getString("pass"));
                urLp.add(iLuser);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return urLp;
    }
    
    public ArrayList<BlueUser> ulnoP()
    {

        ArrayList<BlueUser> urLnp = new ArrayList<BlueUser>();
        Connection con = BlurConnction.getConnection();
        Statement uS;
        ResultSet uR;
        try {
            uS = con.createStatement();
            uR = uS.executeQuery("SELECT * from user");
            while(uR.next())
            {
                BlueUser iLuser = new BlueUser(
                        uR.getString("fname"),
                        uR.getString("lname"),
                        uR.getString("username")
                        );
                urLnp.add(iLuser);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return urLnp;
    }
}
