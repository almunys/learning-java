/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlueboxPack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class eventClass {
    int iD;
    String Event;
    String location;
    String date_in;
    String date_out;
    String L_user;
    String audio;
    String light;
    String video;
    String rigg;
    String electric;
    String addediTems;
    String Details;
    String report;
    String L_report;

    public eventClass() {
    }

    public eventClass(int iD, String Event, String location, String date_out, String L_user) {
        this.iD = iD;
        this.Event = Event;
        this.location = location;
        this.date_out = date_out;
        this.L_user = L_user;
    }

    public eventClass(String Event, String location, String date_in, String date_out, String L_user, String audio, String light, String video, String rigg, String electric, String addediTems, String Details, String report, String L_report) {
        this.Event = Event;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.L_user = L_user;
        this.audio = audio;
        this.light = light;
        this.video = video;
        this.rigg = rigg;
        this.electric = electric;
        this.addediTems = addediTems;
        this.Details = Details;
        this.report = report;
        this.L_report = L_report;
    }

    public eventClass(int iD, String Event, String location, String date_in, String date_out, String L_user, String audio, String light, String video, String rigg, String electric, String addediTems, String Details, String report, String L_report) {
        this.iD = iD;
        this.Event = Event;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.L_user = L_user;
        this.audio = audio;
        this.light = light;
        this.video = video;
        this.rigg = rigg;
        this.electric = electric;
        this.addediTems = addediTems;
        this.Details = Details;
        this.report = report;
        this.L_report = L_report;
    }

    public int getiD() {
        return iD;
    }

    public void setiD(int iD) {
        this.iD = iD;
    }

    public String getEvent() {
        return Event;
    }

    public void setEvent(String Event) {
        this.Event = Event;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDate_in() {
        return date_in;
    }

    public void setDate_in(String date_in) {
        this.date_in = date_in;
    }

    public String getDate_out() {
        return date_out;
    }

    public void setDate_out(String date_out) {
        this.date_out = date_out;
    }

    public String getL_user() {
        return L_user;
    }

    public void setL_user(String L_user) {
        this.L_user = L_user;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public String getLight() {
        return light;
    }

    public void setLight(String light) {
        this.light = light;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getRigg() {
        return rigg;
    }

    public void setRigg(String rigg) {
        this.rigg = rigg;
    }

    public String getElectric() {
        return electric;
    }

    public void setElectric(String electric) {
        this.electric = electric;
    }

    public String getAddediTems() {
        return addediTems;
    }

    public void setAddediTems(String addediTems) {
        this.addediTems = addediTems;
    }

    public String getDetails() {
        return Details;
    }

    public void setDetails(String Details) {
        this.Details = Details;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public String getL_report() {
        return L_report;
    }

    public void setL_report(String L_report) {
        this.L_report = L_report;
    }
    
    public ArrayList<eventClass> smallist()
    {
        ArrayList<eventClass> sList =  new ArrayList<eventClass>();
        Connection con = BlurConnction.getConnection();
        Statement sT;
        ResultSet rT;
        try {
            sT = con.createStatement();
            rT = sT.executeQuery("SELECT `iD`,`Event`, `location`, `date_out`, `L_user`  FROM `Ev`");
            while(rT.next())
            {
                eventClass nSlist = new eventClass(
                        rT.getInt("iD"),
                        rT.getString("Event"),
                        rT.getString("location"),
                        rT.getString("date_out"),
                        rT.getString("L_user"));
                sList.add(nSlist);
            }
        } catch (SQLException ex) {
            Logger.getLogger(eventClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sList;
    }
    
    public ArrayList<eventClass> Fullist()
    {
        ArrayList<eventClass> fLlist = new ArrayList<eventClass>();
        Connection con = BlurConnction.getConnection();
        PreparedStatement sT;
        ResultSet rS;
        try {
            sT = con.prepareStatement("SELECT `iD`, `Event`, `location`, `e_date`, `date_in`, `date_out`, `L_user`, `audio`, `light`, `video`, `rigg`, `electric`, `addediTems`, `Details`, `report`, `L_report` FROM `Ev` WHERE iD = ?");
            sT.setInt(1, GlobaleBlue.eventId);
            rS = sT.executeQuery();
            while(rS.next())
            {
                eventClass nMflist = new eventClass(
                        rS.getInt("iD"),
                        rS.getString("Event"),
                        rS.getString("location"),
                        rS.getString("date_in"),
                        rS.getString("date_out"),
                        rS.getString("L_user"),
                        rS.getString("audio"),
                        rS.getString("light"),
                        rS.getString("video"),
                        rS.getString("rigg"),
                        rS.getString("electric"),
                        rS.getString("addediTems"),
                        rS.getString("Details"),
                        rS.getString("report"),
                        rS.getString("L_report"));
                fLlist.add(nMflist);
            }
        } catch (SQLException ex) {
            Logger.getLogger(eventClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fLlist;
    }
    
    public boolean createEvent(eventClass nurF)
    {
        boolean eV = true;
        Connection con = BlurConnction.getConnection();
        PreparedStatement pS;
        try {
            pS = con.prepareStatement("INSERT INTO `Ev` (`iD`, `Event`, `location`, `date_in`, `date_out`, `L_user`, `audio`, `light`, `video`, `rigg`, `electric`, `addediTems`, `Details`, `report`, `L_report`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            pS.setString(1, nurF.getEvent());
            pS.setString(2, nurF.getLocation());
            pS.setString(3, nurF.getDate_in());
            pS.setString(4, nurF.getDate_out());
            pS.setString(5, nurF.getL_user());
            pS.setString(6, nurF.getAudio());
            pS.setString(7, nurF.getLight());
            pS.setString(8, nurF.getVideo());
            pS.setString(9, nurF.getRigg());
            pS.setString(10, nurF.getElectric());
            pS.setString(11, nurF.getAddediTems());
            pS.setString(12, nurF.getDetails());
            pS.setString(13, nurF.getReport());
            pS.setString(14, nurF.getL_report());
            if(pS.executeUpdate() !=0)
            {
                System.out.println(eV + " __ Created");
                eV = true;
            }
            else
            {
                System.out.println(eV + " __ Created");
                eV = false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(eventClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return eV;
    }
    
    public boolean updateEvent(int eU)
    {
        boolean event = true;
        String upDaiD = null;
        if(event == true)
        {
            upDaiD = "UPDATE Ev SET Event = ?, location = ?"//1 ,2
                    + ", date_in = ?"//3
                    + ", date_out = ?"//4
                    + ", L_user = ?"//5
                    + ", audio = ?"//6
                    + ", light = ?"//7
                    + ", video = ?"//8
                    + ", rigg = ?"//9
                    + ", electric = ?"//10
                    + ", addediTems = ?"//11
                    + ", Details = ?"//12
                    + ", report = ?"//13
                    + ", L_report = ? WHERE iD = ?";//14 ,15
            Connection con = BlurConnction.getConnection();
            PreparedStatement eP;
            try {
                eP = con.prepareStatement(upDaiD);
                eP.setString(1, getEvent());
                eP.setString(2, getLocation());
                eP.setString(3, getDate_in());
                eP.setString(4, getDate_out());
                eP.setString(5, getL_user());
                eP.setString(6, getAudio());
                eP.setString(7, getLight());
                eP.setString(8, getVideo());
                eP.setString(9, getRigg());
                eP.setString(10, getElectric());
                eP.setString(11, getAddediTems());
                eP.setString(12, getDetails());
                eP.setString(13, getReport());
                eP.setString(14, getL_report());
                eP.setInt(15, GlobaleBlue.eventId);
                eP.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(eventClass.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return event;
    }
}

