package BlueboxPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class BlurConnction {
    public static Connection getConnection() 
    {
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://110.100.90.250/bluebox_dB", "flooger", "nm901333");
        } catch (SQLException ex) {
            Logger.getLogger(BlurConnction.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
    
}
