package BlueboxPack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class Blueticket {
    
    private int TiD;
    private String title;
    private String description;
    private String location;
    private String tAdmin;
    private String StartD;
    private String EndD;
    private String AssigndEng;
    private String Report;
    private String Status;

    public Blueticket() {
    }

    public Blueticket(int TiD, String Report, String Status) {
        this.TiD = TiD;
        this.Report = Report;
        this.Status = Status;
    }

    
    public Blueticket(String title, String description, String location, String tAdmin, String StartD, String EndD, String AssigndEng, String Report, String Status) {
        this.title = title;
        this.description = description;
        this.location = location;
        this.tAdmin = tAdmin;
        this.StartD = StartD;
        this.EndD = EndD;
        this.AssigndEng = AssigndEng;
        this.Report = Report;
        this.Status = Status;
    }

    public Blueticket(int TiD, String title, String description, String location, String tAdmin, String StartD, String EndD, String AssigndEng, String Report, String Status) {
        this.TiD = TiD;
        this.title = title;
        this.description = description;
        this.location = location;
        this.tAdmin = tAdmin;
        this.StartD = StartD;
        this.EndD = EndD;
        this.AssigndEng = AssigndEng;
        this.Report = Report;
        this.Status = Status;
    }

    public int getTiD() {
        return TiD;
    }

    public void setTiD(int TiD) {
        this.TiD = TiD;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String gettAdmin() {
        return tAdmin;
    }

    public void settAdmin(String tAdmin) {
        this.tAdmin = tAdmin;
    }

    public String getStartD() {
        return StartD;
    }

    public void setStartD(String StartD) {
        this.StartD = StartD;
    }

    public String getEndD() {
        return EndD;
    }

    public void setEndD(String EndD) {
        this.EndD = EndD;
    }

    public String getAssigndEng() {
        return AssigndEng;
    }

    public void setAssigndEng(String AssigndEng) {
        this.AssigndEng = AssigndEng;
    }

    public String getReport() {
        return Report;
    }

    public void setReport(String Report) {
        this.Report = Report;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
    

    
    
    
    public ArrayList<Blueticket> tKList()
    {
        ArrayList<Blueticket> iTL = new ArrayList<Blueticket>();
        Connection con = BlurConnction.getConnection();
        Statement sT;
        ResultSet rT;
        try {
            sT = con.createStatement();
            rT = sT.executeQuery("SELECT `TiD`, `title`, `description`, `location`, `tAdmin`, `StartD`, `EndD`, `AssigndEng`, `Report`, `Status` FROM `MT`");
            while(rT.next())
            {
                Blueticket TList = new Blueticket(rT.getInt("TiD"),
                        rT.getString("title"),
                        rT.getString("description"),
                        rT.getString("location"),
                        rT.getString("tAdmin"),
                        rT.getString("StartD"),
                        rT.getString("EndD"),
                        rT.getString("AssigndEng"),
                        rT.getString("Report"),
                        rT.getString("Status"));
                iTL.add(TList);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Blueticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return iTL;
    }
    
    public boolean editTick(Blueticket Tic) //"TiD","title","description","location","tAdmin","StartD","EndD","AssigndEng","Report","Status"
    {
        boolean TiK = true;
        Connection con = BlurConnction.getConnection();
        PreparedStatement Pe;
        String TickUpdate = "";
        if(Tic != null)
        {
            TickUpdate = "UPDATE `MT` SET `title` = ?, `description` = ?, `location` = ?, `tAdmin` = ?, `StartD` = ?, `EndD` = ?, `AssigndEng` = ?, `Report` = ?, `Status` = ? WHERE `MT` . `TiD` = ?";
            try {
                Pe = con.prepareStatement(TickUpdate);
                Pe.setString(1, Tic.getTitle());
                Pe.setString(2, Tic.getDescription());
                Pe.setString(3, Tic.getLocation());
                Pe.setString(4, Tic.gettAdmin());
                Pe.setString(5, Tic.getStartD());
                Pe.setString(6, Tic.getEndD());
                Pe.setString(7, Tic.getAssigndEng());
                Pe.setString(8, Tic.getReport());
                Pe.setString(9, Tic.getStatus());
                Pe.setInt(10, GlobaleBlue.tickId);
                if(Pe.executeUpdate() != 0)
                {
                    JOptionPane.showMessageDialog(null, "Tickit : " + Tic.getTitle() + " is now open");
                }
            } catch (SQLException ex) {
                Logger.getLogger(Blueticket.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return TiK;
    }
    
    public boolean editReportTick(Blueticket Tic)
    {
        boolean TiK = true;
        Connection con = BlurConnction.getConnection();
        PreparedStatement Per;
        String TicRrepoUpD = "UPDATE `MT` SET `Report` = ? WHERE `MT` . `TiD` = ?";
        if(Tic != null)
        {
            TicRrepoUpD = "UPDATE `MT` SET `Report` = ? WHERE `MT` . `TiD` = ?";
            try {
                Per = con.prepareStatement(TicRrepoUpD);
                Per.setString(1, Tic.getReport());
                Per.setInt(2, GlobaleBlue.tickId);
                if(Per.executeUpdate() != 0)
                {
                    JOptionPane.showMessageDialog(null, "Your report is submeted\n Thank You.");
                }
            } catch (SQLException ex) {
                Logger.getLogger(Blueticket.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return TiK;
    }
}
