package BlueboxPack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Khaled Almunys developer for bluebox
 */
public class blueItem {
    private int iD;
    private String kInd;
    private String iTem;
    private String tYpes;
    private String bRand;
    private int qNty;

    public blueItem(int iD, String kInd) {
        this.iD = iD;
        this.kInd = kInd;
    }

    public blueItem(int iD, String bRand, int qNty)
            {
                this.iD = iD;
                this.bRand = bRand;
                this.qNty = qNty;
            }
    
    public blueItem() {
    }

    public blueItem(int iD, String kInd, String iTem, String tYpes, String bRand, int qNty) {
        this.iD = iD;
        this.kInd = kInd;
        this.iTem = iTem;
        this.tYpes = tYpes;
        this.bRand = bRand;
        this.qNty = qNty;
    }

    blueItem(String kInd, String iTem, String tYpes, String bRand, int qNty) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

//    blueItem(String Kind, String item, String types, String brand, int qunt) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    public int getiD() {
        return iD;
    }

    public void setiD(int iD) {
        this.iD = iD;
    }

    public String getkInd() {
        return kInd;
    }

    public void setkInd(String kInd) {
        this.kInd = kInd;
    }

    public String getiTem() {
        return iTem;
    }

    public void setiTem(String iTem) {
        this.iTem = iTem;
    }

    public String gettYpes() {
        return tYpes;
    }

    public void settYpes(String tYpes) {
        this.tYpes = tYpes;
    }

    public String getbRand() {
        return bRand;
    }

    public void setbRand(String bRand) {
        this.bRand = bRand;
    }

    public int getqNty() {
        return qNty;
    }

    public void setqNty(int qNty) {
        this.qNty = qNty;
    }
    
    public void ColNlist(String ClN, String iTx)
    {
        Connection con = BlurConnction.getConnection();
        PreparedStatement pst;
        ResultSet rS;
        String Tih = ClN;
        String lqs = "SELECT DISTINCT ? FROM `Sitems` ORDER BY ?";
        try {
            pst = con.prepareStatement(lqs);
            pst.setString(1, Tih);
            pst.setString(2, Tih);
            rS = pst.executeQuery();
            while(rS.next())
            {
                
                System.out.println(iTx + "_ " + rS.getString(ClN));
                System.out.println(GlobaleBlue.brandL + "_" + GlobaleBlue.kindL + "_" + GlobaleBlue.itemL);
                if(ClN == "brand")
                {
                    //GlobaleBlue.brandL = rS.getString(ClN);
                    System.out.println(iTx + "_B " + rS.getString(ClN));
                }
                else if(ClN == "kind")
                        {
                            System.out.println(iTx + "_K " + rS.getString(ClN));
                        }
                
                else
                {
                    System.out.println(iTx + "_I " + rS.getString(ClN));
                }
                System.out.println(GlobaleBlue.brandL + "_" + GlobaleBlue.kindL + "_" + GlobaleBlue.itemL);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueItem.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
//    public void Tmonk(String Cat, String targ)
//    {
//        String choiss;
//        choiss = Cat;
 //       switch (choiss)
 //       {
 //           case "brand":
  //              System.out.println("__brand " + targ);
//                Connection con = BlurConnction.getConnection();
//                PreparedStatement psT;
//                ResultSet rSt;
//                break;
//            case "kind":
//                System.out.println("_kind " + targ);
//                Connection con = BlurConnction.getConnection();
//                PreparedStatement psT;
//                ResultSet rSt;
//                break;
//            case "item":
//                System.out.println("_item " + targ);
//                Connection con = BlurConnction.getConnection();
//                PreparedStatement psT;
//                ResultSet rSt;
//                break;
//        }
        
    public ArrayList<blueItem> pKli()
    {
        ArrayList<blueItem> pK = new ArrayList<blueItem>();
        Connection con = BlurConnction.getConnection();
        Statement sT;
        ResultSet rS;
        try {
            sT = con.createStatement();
            rS = sT.executeQuery("SELECT `ID`, `kind`, `item`, `types`, `brand`, `quantity` FROM `Sitems`");
            while(rS.next())
            {
                blueItem pKl = new blueItem(
                        rS.getInt("iD"),
                        rS.getString("kInd"),
                        rS.getString("iTem"),
                        rS.getString("tYpes"),
                        rS.getString("bRand"),
                        rS.getInt("qNty"));
                pK.add(pKl);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueItem.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
