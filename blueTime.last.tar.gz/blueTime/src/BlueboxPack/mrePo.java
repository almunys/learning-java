
package BlueboxPack;

import static com.mysql.cj.MysqlType.SET;
import static java.awt.event.PaintEvent.UPDATE;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Khaled Almunys bluebox Develop
 */
public class mrePo {
    int ID;
    String item;
    String location;
    String date_in;
    String date_out;
    String user_local;
    String end_user_audio;
    String end_user_light;
    String end_user_video;
    String end_user_reging;
    String end_user_general;
    String end_user_E_elecrission;
    String end_user_E_events;
    String itemsA;
    String initial_ticket_text;
    String report_action;
    String local_reeport;

    public mrePo() {
    }

    public mrePo(int ID, String item, String location, String date_in, String date_out, String user_local, String end_user_audio, String end_user_light, String end_user_video, String end_user_reging, String end_user_general, String end_user_E_elecrission, String end_user_E_events, String initial_ticket_text, String report_action, String local_reeport) {
        this.ID = ID;
        this.item = item;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.user_local = user_local;
        this.end_user_audio = end_user_audio;
        this.end_user_light = end_user_light;
        this.end_user_video = end_user_video;
        this.end_user_reging = end_user_reging;
        this.end_user_general = end_user_general;
        this.end_user_E_elecrission = end_user_E_elecrission;
        this.end_user_E_events = end_user_E_events;
        this.initial_ticket_text = initial_ticket_text;
        this.report_action = report_action;
        this.local_reeport = local_reeport;
    }

    public mrePo(int ID, String item, String location, String date_in, String date_out, String user_local, String end_user_audio, String end_user_light, String end_user_video, String end_user_reging, String end_user_E_elecrission, String itemsA, String initial_ticket_text, String report_action, String local_reeport) {
        this.ID = ID;
        this.item = item;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.user_local = user_local;
        this.end_user_audio = end_user_audio;
        this.end_user_light = end_user_light;
        this.end_user_video = end_user_video;
        this.end_user_reging = end_user_reging;
        this.end_user_E_elecrission = end_user_E_elecrission;
        this.itemsA = itemsA;
        this.initial_ticket_text = initial_ticket_text;
        this.report_action = report_action;
        this.local_reeport = local_reeport;
    }

    public mrePo(String item, String location, String date_in, String date_out, String user_local, String end_user_audio, String end_user_light, String end_user_video, String end_user_reging, String end_user_E_elecrission, String initial_ticket_text, String report_action, String local_reeport) {
        this.item = item;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.user_local = user_local;
        this.end_user_audio = end_user_audio;
        this.end_user_light = end_user_light;
        this.end_user_video = end_user_video;
        this.end_user_reging = end_user_reging;
        this.end_user_E_elecrission = end_user_E_elecrission;
        this.initial_ticket_text = initial_ticket_text;
        this.report_action = report_action;
        this.local_reeport = local_reeport;
    }

    public mrePo(int ID, String item, String location, String date_in, String date_out, String user_local, String end_user_audio, String end_user_light, String end_user_video, String end_user_reging, String end_user_E_elecrission, String initial_ticket_text, String report_action, String local_reeport) {
        this.ID = ID;
        this.item = item;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.user_local = user_local;
        this.end_user_audio = end_user_audio;
        this.end_user_light = end_user_light;
        this.end_user_video = end_user_video;
        this.end_user_reging = end_user_reging;
        this.end_user_E_elecrission = end_user_E_elecrission;
        this.initial_ticket_text = initial_ticket_text;
        this.report_action = report_action;
        this.local_reeport = local_reeport;
    }

    
    

    public mrePo(String item, String location, String date_in, String date_out, String user_local, String end_user_audio, String end_user_light, String end_user_video, String end_user_reging, String end_user_E_elecrission, String itemsA, String initial_ticket_text, String report_action, String local_reeport) {
        this.item = item;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.user_local = user_local;
        this.end_user_audio = end_user_audio;
        this.end_user_light = end_user_light;
        this.end_user_video = end_user_video;
        this.end_user_reging = end_user_reging;
        this.end_user_E_elecrission = end_user_E_elecrission;
        this.itemsA = itemsA;
        this.initial_ticket_text = initial_ticket_text;
        this.report_action = report_action;
        this.local_reeport = local_reeport;
    }

    
    public mrePo(int ID, String item, String location, String date_out, String user_local) {
        this.ID = ID;
        this.item = item;
        this.location = location;
        this.date_out = date_out;
        this.user_local = user_local;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDate_in() {
        return date_in;
    }

    public void setDate_in(String date_in) {
        this.date_in = date_in;
    }

    public String getDate_out() {
        return date_out;
    }

    public void setDate_out(String date_out) {
        this.date_out = date_out;
    }

    public String getUser_local() {
        return user_local;
    }

    public void setUser_local(String user_local) {
        this.user_local = user_local;
    }


    public String getEnd_user_audio() {
        return end_user_audio;
    }

    public void setEnd_user_audio(String end_user_audio) {
        this.end_user_audio = end_user_audio;
    }

    public String getEnd_user_light() {
        return end_user_light;
    }

    public void setEnd_user_light(String end_user_light) {
        this.end_user_light = end_user_light;
    }

    public String getEnd_user_video() {
        return end_user_video;
    }

    public void setEnd_user_video(String end_user_video) {
        this.end_user_video = end_user_video;
    }

    public String getEnd_user_reging() {
        return end_user_reging;
    }

    public void setEnd_user_reging(String end_user_reging) {
        this.end_user_reging = end_user_reging;
    }

    public String getEnd_user_general() {
        return end_user_general;
    }

    public void setEnd_user_general(String end_user_general) {
        this.end_user_general = end_user_general;
    }

    public String getEnd_user_E_elecrission() {
        return end_user_E_elecrission;
    }

    public void setEnd_user_E_elecrission(String end_user_E_elecrission) {
        this.end_user_E_elecrission = end_user_E_elecrission;
    }

    public String getEnd_user_E_events() {
        return end_user_E_events;
    }

    public void setEnd_user_E_events(String end_user_E_events) {
        this.end_user_E_events = end_user_E_events;
    }

    public String getItemsA() {
        return itemsA;
    }

    public void setItemsA(String itemsA) {
        this.itemsA = itemsA;
    }

    public String getInitial_ticket_text() {
        return initial_ticket_text;
    }

    public void setInitial_ticket_text(String initial_ticket_text) {
        this.initial_ticket_text = initial_ticket_text;
    }

    public String getReport_action() {
        return report_action;
    }

    public void setReport_action(String report_action) {
        this.report_action = report_action;
    }

    public String getLocal_reeport() {
        return local_reeport;
    }

    public void setLocal_reeport(String local_reeport) {
        this.local_reeport = local_reeport;
    }

    
    

    /**
     * Returns an array list of records that been created for the table
     * <p>
     * this method returns events list in an Array.
     * 
     * @return 
     */
    public ArrayList<mrePo> sMlist()
    {
        ArrayList<mrePo> sList = new ArrayList<mrePo>();
        Connection con = BlurConnction.getConnection();
        Statement sT;
        ResultSet rS;
        try {
            sT = con.createStatement();
            rS = sT.executeQuery("SELECT `iD`,`item`, `location`, `date_out`, `user_local`  FROM `main_repo`");
            while(rS.next())
            {
                mrePo nSList = new mrePo(
                        rS.getInt("ID"),
                        rS.getString("item"),
                        rS.getString("location"),
                        rS.getString("date_out"),
                        rS.getString("user_local"));
                sList.add(nSList);
            }
        } catch (SQLException ex) {
            Logger.getLogger(mrePo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sList;
    }
    
    /**
     * Returns an array list of records that been created
     * <p>
     * this method returns events list in an Array.
     * 
     * @return 
     */
    public ArrayList<mrePo> rMlist()
            {
                ArrayList<mrePo> mList = new ArrayList<mrePo>();
                Connection con = BlurConnction.getConnection();
                PreparedStatement lT;
                ResultSet lS;
        try {
            lT = con.prepareStatement("SELECT `iD`, `item`, `location`, `date_in`, `date_out`, `user_local`, `end_user_audio`, `end_user_light`, `end_user_video`, `end_user_reging`, `end_user_general`, `end_user_E_elecrission`, `end_user_E_events`, `initial_ticket_text`, `report_action`, `local_reeport` FROM `main_repo` WHERE ID = ?");
            lT.setInt(1, GlobaleBlue.eventId);
            lS = lT.executeQuery();
            
            while(lS.next())
            {
                mrePo nMList = new mrePo(
                        lS.getInt("ID"),
                        lS.getString("item"),
                        lS.getString("location"),
                        lS.getString("date_in"),
                        lS.getString("date_out"),
                        lS.getString("user_local"),
                        lS.getString("end_user_audio"),
                        lS.getString("end_user_light"),
                        lS.getString("end_user_video"),
                        lS.getString("end_user_reging"),
                        lS.getString("end_user_general"),
                        lS.getString("end_user_E_elecrission"),
                        lS.getString("end_user_E_events"),
                        lS.getString("initial_ticket_text"),
                        lS.getString("report_action"),
                        lS.getString("local_reeport"));
                mList.add(nMList);
            }
        } catch (SQLException ex) {
            Logger.getLogger(mrePo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mList;
    }
    
    public ArrayList<mrePo> Newlist()
    {
        ArrayList<mrePo> MilList = new ArrayList<mrePo>();
        Connection con = BlurConnction.getConnection();
        PreparedStatement lT;
        ResultSet lS;
        try {
            lT = con.prepareStatement("SELECT `iD`, `item`, `location`, `date_in`, `date_out`, `user_local`, `end_user_audio`, `end_user_light`, `end_user_video`, `end_user_reging`, `end_user_E_elecrission`, `initial_ticket_text`, `report_action`, `local_reeport` FROM `main_repo` WHERE ID = ?");
            lT.setInt(1, GlobaleBlue.eventId);
            lS = lT.executeQuery();
            while(lS.next())
            {
                mrePo nMList = new mrePo(
                        lS.getInt("ID"),
                        lS.getString("item"),
                        lS.getString("location"),
                        lS.getString("date_in"),
                        lS.getString("date_out"),
                        lS.getString("user_local"),
                        lS.getString("end_user_audio"),
                        lS.getString("end_user_light"),
                        lS.getString("end_user_video"),
                        lS.getString("end_user_reging"),
                        lS.getString("end_user_E_elecrission"),
                        lS.getString("initial_ticket_text"),
                        lS.getString("report_action"),
                        lS.getString("local_reeport"));
                MilList.add(nMList);
            }
        } catch (SQLException ex) {
            Logger.getLogger(mrePo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return MilList;
    }

    
    
    
    public boolean insertrecord(mrePo iSk)
    {
        boolean event = true;
        if(event == true)
        {
            Connection con = BlurConnction.getConnection();
            PreparedStatement eP;
            try {
                eP = con.prepareStatement("INSERT INTO `main_repo`( `item`,"
                        + " `location`,"
                        + " `date_in`,"
                        + " `date_out`,"
                        + " `user_local`,"
                        + " `end_user_audio`,"
                        + " `end_user_light`,"
                        + " `end_user_video`,"
                        + " `end_user_reging`,"
                        + " `end_user_E_elecrission`,"
                        + " `itemsA`,"
                        + " `initial_ticket_text`,"
                        + " `report_action`,"
                        + " `local_reeport`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                eP.setString(1, getItem());
                eP.setString(2, getLocation());
                eP.setString(3, getDate_in());
                eP.setString(4, getDate_out());
                eP.setString(5, getUser_local());
                eP.setString(6, getEnd_user_audio());
                eP.setString(7, getEnd_user_light());
                eP.setString(8, getEnd_user_video());
                eP.setString(9, getEnd_user_reging());
                eP.setString(10, getEnd_user_E_elecrission());
                eP.setString(11, getItemsA());
                eP.setString(12, getInitial_ticket_text());
                eP.setString(13, getReport_action());
                eP.setString(14, getLocal_reeport());
                if(eP.executeUpdate() != 0)
                {
                    System.out.println(event + " __ inserted");
                    event = true;
                }
                else
                {
                    System.out.println(event + " __ NO record");
                    event = false;
                }
            } catch (SQLException ex) {
                Logger.getLogger(eVentManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return event;
    }
    
    public boolean updateRecored(int iEr)
    {
        boolean event = true;
        String updateQuiRi = null;
        if(event == true)
        {
//            System.out.println("We ArE HERE??");
            updateQuiRi = "UPDATE main_repo SET item = ?, location = ?"//2
                    + ", date_in = ?"//3
                    + ", date_out = ?"//4
                    + ", user_local = ?"//5
                    //+ ", execution_date = ?"//6
                    + ", end_user_audio = ?"//7
                    + ", end_user_light = ?"//8
                    + ", end_user_video = ?"//9
                    + ", end_user_reging = ?"//10
                    //+ ", end_user_general = ?"//11
                    + ", end_user_E_elecrission = ?"//12
                    //+ ", end_user_E_events = ?"//13
                    + ", itemsA = ?"//14
                    + ", initial_ticket_text = ?"//15
                    + ", report_action = ?, local_reeport = ? WHERE iD = ?";//16 17 18
            Connection con = BlurConnction.getConnection();
            PreparedStatement eP;
            try {
                eP = con.prepareStatement(updateQuiRi);
                eP.setString(1, getItem());
                eP.setString(2, getLocation());
                eP.setString(3, getDate_in());
                eP.setString(4, getDate_out());
                eP.setString(5, getUser_local());
                //eP.setString(6, getExecution_date());
                eP.setString(6, getEnd_user_audio());
                eP.setString(7, getEnd_user_light());
                eP.setString(8, getEnd_user_video());
                eP.setString(9, getEnd_user_reging());
                //eP.setString(10, getEnd_user_general());
                eP.setString(10, getEnd_user_E_elecrission());
                //eP.setString(11, getEnd_user_E_events());
                eP.setString(11, getItemsA());
                eP.setString(12, getInitial_ticket_text());
                eP.setString(13, getReport_action());
                eP.setString(14, getLocal_reeport());
                eP.setInt(15, GlobaleBlue.eventId);
                eP.executeUpdate();
                } catch (SQLException ex) 
                {
                Logger.getLogger(mrePo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return event;
    }
    
    public void deletRecord(int iDd)
    {
        System.out.println(iDd);
        Connection con = BlurConnction.getConnection();
        PreparedStatement Dr;
        try {
            Dr = con.prepareStatement("DELETE FROM main_repo WHERE iD = ?");
            Dr.setInt(1, iDd);
            if(Dr.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "Record Deleted");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Error 133!!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(mrePo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
