package BlueBoxTest;

import javax.swing.Icon;
import javax.swing.table.AbstractTableModel;




/**
 *
 * @author Developer Khaled Almunys
 */
public class blueTModel  extends AbstractTableModel {
    
    private String[] columns;
    private Object[][] rows;
    public blueTModel(){}
    public blueTModel(Object[][] data, String[] columnsName)
    {
        this.columns = columnsName;
        this.rows = data;
    }
    public Class getColumnClass(int col)
    {
        if(col == 6)
        {
            return Icon.class;
        }
        else 
        {
            return getValueAt(0, col).getClass();
        }
    }

    @Override
    public int getRowCount() {
        return this.rows.length;
    }

    @Override
    public int getColumnCount() {
        return this.columns.length;
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return this.rows[rowIndex][columnIndex];
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public String getColumnName(int col)
    {
        return this.columns[col];
    }
}
