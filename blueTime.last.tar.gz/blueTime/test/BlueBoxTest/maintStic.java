package BlueBoxTest;

/**
 *
 * @author Developer Khaled Almunys
 */
public class maintStic {
    private int ID;
    private String item;
    private String location;
    private String date_in;
    private String date_out;
    private String user_local;
    private String ex_date;
    private String end_u_audio;
    private String end_u_light;
    private String end_u_video;
    private String end_u_reg;
    private String end_u_gen;
    private String end_user_elictric;
    private String end_user_even;
    private String int_ticket;
    private String report_act;
    private String local_report;

    public maintStic(int ID, String item, String location, String date_in, String date_out, String user_local, String ex_date, String end_u_audio, String end_u_light, String end_u_video, String end_u_reg, String end_u_gen, String end_user_elictric, String end_user_even, String int_ticket, String report_act, String local_report) {
        this.ID = ID;
        this.item = item;
        this.location = location;
        this.date_in = date_in;
        this.date_out = date_out;
        this.user_local = user_local;
        this.ex_date = ex_date;
        this.end_u_audio = end_u_audio;
        this.end_u_light = end_u_light;
        this.end_u_video = end_u_video;
        this.end_u_reg = end_u_reg;
        this.end_u_gen = end_u_gen;
        this.end_user_elictric = end_user_elictric;
        this.end_user_even = end_user_even;
        this.int_ticket = int_ticket;
        this.report_act = report_act;
        this.local_report = local_report;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDate_in() {
        return date_in;
    }

    public void setDate_in(String date_in) {
        this.date_in = date_in;
    }

    public String getDate_out() {
        return date_out;
    }

    public void setDate_out(String date_out) {
        this.date_out = date_out;
    }

    public String getUser_local() {
        return user_local;
    }

    public void setUser_local(String user_local) {
        this.user_local = user_local;
    }

    public String getEx_date() {
        return ex_date;
    }

    public void setEx_date(String ex_date) {
        this.ex_date = ex_date;
    }

    public String getEnd_u_audio() {
        return end_u_audio;
    }

    public void setEnd_u_audio(String end_u_audio) {
        this.end_u_audio = end_u_audio;
    }

    public String getEnd_u_light() {
        return end_u_light;
    }

    public void setEnd_u_light(String end_u_light) {
        this.end_u_light = end_u_light;
    }

    public String getEnd_u_video() {
        return end_u_video;
    }

    public void setEnd_u_video(String end_u_video) {
        this.end_u_video = end_u_video;
    }

    public String getEnd_u_reg() {
        return end_u_reg;
    }

    public void setEnd_u_reg(String end_u_reg) {
        this.end_u_reg = end_u_reg;
    }

    public String getEnd_u_gen() {
        return end_u_gen;
    }

    public void setEnd_u_gen(String end_u_gen) {
        this.end_u_gen = end_u_gen;
    }

    public String getEnd_user_elictric() {
        return end_user_elictric;
    }

    public void setEnd_user_elictric(String end_user_elictric) {
        this.end_user_elictric = end_user_elictric;
    }

    public String getEnd_user_even() {
        return end_user_even;
    }

    public void setEnd_user_even(String end_user_even) {
        this.end_user_even = end_user_even;
    }

    public String getInt_ticket() {
        return int_ticket;
    }

    public void setInt_ticket(String int_ticket) {
        this.int_ticket = int_ticket;
    }

    public String getReport_act() {
        return report_act;
    }

    public void setReport_act(String report_act) {
        this.report_act = report_act;
    }

    public String getLocal_report() {
        return local_report;
    }

    public void setLocal_report(String local_report) {
        this.local_report = local_report;
    }

}
