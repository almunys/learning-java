package BlueBoxTest;

import BlueBoxTest.Sitems;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Developer Khaled Almunys
 */
public class blueQuery {
    public boolean insertmaintenance(maintStic maint)
    {
        //INSERT INTO `main_repo`(`item`, `location`, `date_in`, `date_out`, `user_local`, `execution_date`, `end_user_audio`, `end_user_light`, `end_user_video`, `end_user_reging`, `end_user_general`, `end_user_E_elecrission`, `end_user_E_events`, `initial_ticket_text`, `report_action`, `local_report`) VALUES ()
        boolean recordIsCeated = true;
        Connection con =  blueConnection.getConnected();
        PreparedStatement ps;
        
        try {
            ps = con.prepareStatement("INSERT INTO `main_repo`(`item`, `location`, `date_in`, `date_out`, `user_local`, `execution_date`, `end_user_audio`, `end_user_light`, `end_user_video`, `end_user_reging`, `end_user_general`, `end_user_E_elecrission`, `end_user_E_events`, `initial_ticket_text`, `report_action`, `local_report`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, maint.getItem());
            ps.setString(2, maint.getLocation());
            ps.setString(3, maint.getDate_in());
            ps.setString(4, maint.getDate_out());
            ps.setString(5, maint.getUser_local());
            ps.setString(6, maint.getEx_date());
            ps.setString(7, maint.getEnd_u_audio());
            ps.setString(8, maint.getEnd_u_light());
            ps.setString(9, maint.getEnd_u_video());
            ps.setString(10, maint.getEnd_u_reg());
            ps.setString(11, maint.getEnd_u_gen());
            ps.setString(12, maint.getEnd_user_elictric());
            ps.setString(13, maint.getEnd_user_even());
            ps.setString(14, maint.getInt_ticket());
            ps.setString(15, maint.getReport_act());
            ps.setString(16, maint.getLocal_report());
            
            if(ps.executeUpdate() != 0){
                            JOptionPane.showMessageDialog(null, "New record Created");
                            recordIsCeated = true;
                            }
                            else{
                                JOptionPane.showMessageDialog(null, "error 123!");
                                recordIsCeated = false;
                            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return recordIsCeated;
    }
    
    public boolean insertItem(Sitems itm)
    {
        //int ID, String kind, String item, String types, String brand
        boolean itemIsCreated = true;
        Connection con =  blueConnection.getConnected();
        PreparedStatement ps;
        
        try {
            ps = con.prepareStatement("INSERT INTO `Sitems`( `kind`, `item`, `types`, `brand`, `quntity`) VALUES (?,?,?,?,?)");
            ps.setString(1, itm.getKind());
            ps.setString(2, itm.getItem());
            ps.setString(3, itm.getTypes());
            ps.setString(4, itm.getBrand());
            ps.setInt(5, itm.getQuntity());
            
            if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "New Item inserted");
                itemIsCreated = true;
                }
                else{
                    JOptionPane.showMessageDialog(null, "error 124!");
                    itemIsCreated = false;
                }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return itemIsCreated;
    }
    
    public ArrayList<Sitems> itmAlist()
    {
        ArrayList<Sitems> itList = new ArrayList<Sitems>();
        Connection con = blueConnection.getConnected();
        Statement st;
        ResultSet rt;
        try {
            st = con.createStatement();
            rt = st.executeQuery("SELECT `ID`, `kind`, `item`, `types`, `brand`, `quantity` FROM `Sitems`");
            while(rt.next())
            {
                Sitems iAl = new Sitems(
                        rt.getInt("ID"),
                        rt.getString("kind"),
                        rt.getString("item"),
                        rt.getString("types"),
                        rt.getString("brand"),
                        rt.getInt("quantity"));
                itList.add(iAl);
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return itList;
    }
    
//    public ArrayList<tTrack> tlList()
//    {
//        ArrayList<tTrack> tList = new ArrayList<tTrack>();
//        Connection con = blueConnection.getConnected();
//        Statement st;
//        ResultSet rs;
//        
//        try {
//            st =con.createStatement();
//            rs = st.executeQuery("SELECT `iD`, `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack`");
//            while(rs.next())
//            {
//                tTrack tAl = new tTrack(
//                        rs.getInt("iD"),
//                        rs.getInt("item_id"),
//                        rs.getString("location"),
//                        rs.getString("date_out"),
//                        rs.getString("date_back"),
//                        rs.getInt("qunt"),
//                        rs.getBoolean("alert"),
//                        rs.getString("action_note")
//                );
//                tList.add(tAl);    
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return tList;
//    }
    
    public ArrayList<tTrack> tList()
    {
        //rs = st.executeQuery("SELECT `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack` WHERE `item_id` = ?");
        ArrayList<tTrack> tList = new ArrayList<tTrack>();
        Connection con = blueConnection.getConnected();
        PreparedStatement ps;
        ResultSet rs;
        
        try {
            ps = con.prepareStatement("SELECT `iD`, `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack` WHERE `item_id` = ?");
            ps.setInt(1, global.itemsIdQ);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                tTrack tAl = new tTrack(
                        rs.getInt("iD"),
                        rs.getInt("item_id"),
                        rs.getString("location"),
                        rs.getString("date_out"),
                        rs.getString("date_back"),
                        rs.getInt("qunt"),
                        rs.getBoolean("alert"),
                        rs.getString("action_note")
                );
                tList.add(tAl);    
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tList;
    }
    

//    public class Funct{
//        Connection con = null;
//        ResultSet rs = null;
//        PreparedStatement ps = null;
//        public ResultSet find(int ke){
//            try {
//                con = DriverManager.getConnection("jdbc:mysql://swi.bluebox.com.kw/nccal_dB", "flooger", "nm901333");
//                ps = con.prepareStatement("SELECT `item_id`, `location`, `date_out`, `date_back`, `qunt`, `alert`, `action_note` FROM `Ttrack` WHERE `item_id` = ?");
//                ps.setInt(1, ke);
//                rs = ps.executeQuery();
//            }catch(Exception xe){ JOptionPane.showMessageDialog(null, xe); }
//            return rs;
//        }
//    }
    
    public ArrayList<userS> userList()
            
        {
            
            ArrayList<userS> uslist = new ArrayList<userS>();
            Connection con = blueConnection.getConnected();
            Statement st;
            ResultSet rs;
            
        try {
            st = con.createStatement();
        
                rs = st.executeQuery("SELECT `id`, `fname`, `lname`, `username`, `pass` FROM `user`");

                userS ul;

                while(rs.next()){
                    ul = new userS(
                            rs.getInt("Id"),
                            rs.getString("fname"),
                            rs.getString("lname"),
                            rs.getString("username"),
                            rs.getString("pass"));

                    uslist.add(ul);
                    System.out.println(ul);
                }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return uslist;
    }
    
    public void deleteUser(int uId)
    {
        Connection con = blueConnection.getConnected();
        PreparedStatement ps;
        try {
            ps = con.prepareStatement("DELETE FROM 'user' WHERE 'user'.'id' = ?");
            ps.setInt(1, uId);
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "User Deleted!");
            }else{
                JOptionPane.showMessageDialog(null, "User had a boul movement!?!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(blueQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
