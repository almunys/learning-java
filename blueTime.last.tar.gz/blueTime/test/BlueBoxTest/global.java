package BlueBoxTest;

/**
 *@author
 * Khaled Almunys developer for bluebox
 * @author kalmunys
 */
public class global {
    
    static int itemsIdQ ;
    static String[] locations;
    
    public static void main(String[] args) {
        
    }
}
