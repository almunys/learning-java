package BlueBoxTest;

import BlueboxPack.*;

/**
 *
 * @author Developer Khaled Almunys
 */
public class Sitems {
    private int ID;
    private String kind;
    private String item;
    private String types;
    private String brand;
    private int quntity;


    public Sitems(String kind, String item, String types, String brand, int quntity) {
        this.ID = ID;
        this.kind = kind;
        this.item = item;
        this.types = types;
        this.brand = brand;
        this.quntity = quntity;
    }

//    Sitems(String kind, String item, String types, String brand, int quntity) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

//    Sitems(int iD, String kind, String item, String types, String brand, int quntity) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    Sitems(int aInt, String string, String string0, String string1, String string2, int aInt0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    public int getID() {
        return ID;
    }
//
//    public void setID(int ID) {
//        this.ID = ID;
//    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getTypes() {
        return types;
    }

    public void setTypes(String types) {
        this.types = types;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getQuntity() {
        return quntity;
    }

    public void setQuntity(int quntity) {
        this.quntity = quntity;
    }

//    Object getID() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
}
