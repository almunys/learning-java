/*  
Devs khaled almunys Bluebox
*/
package BlueBoxTest;

public class tTrack {
    private int iD;
    private int itmId;
    private String location;
    private String dateOut;
    private String dateBack;
    private int qunt;
    private boolean alert;
    private String actionNote;

    public tTrack() {
    }

    public tTrack(int iD, int itmId, String location, String dateOut, String dateBack, int qunt, boolean alert, String actionNote) {
        this.iD = iD;
        this.itmId = itmId;
        this.location = location;
        this.dateOut = dateOut;
        this.dateBack = dateBack;
        this.qunt = qunt;
        this.alert = alert;
        this.actionNote = actionNote;
    }
    
    public int getiD() {
        return iD;
    }
    
    public void setiD(int iD) {
        this.iD = iD;
    }

    public int getItmId() {
        return itmId;
    }

    public void setItmId(int itmId) {
        this.itmId = itmId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDateOut() {
        return dateOut;
    }

    public void setDateOut(String dateOut) {
        this.dateOut = dateOut;
    }

    public String getDateBack() {
        return dateBack;
    }

    public void setDateBack(String dateBack) {
        this.dateBack = dateBack;
    }

    public int getQunt() {
        return qunt;
    }

    public void setQunt(int qunt) {
        this.qunt = qunt;
    }

    public boolean isAlert() {
        return alert;
    }

    public void setAlert(boolean alert) {
        this.alert = alert;
    }

    public String getActionNote() {
        return actionNote;
    }

    public void setActionNote(String actionNote) {
        this.actionNote = actionNote;
    }
    
}
