package BlueBoxTest;

import java.util.ArrayList;



/**
 *
 * @author Developer Khaled Almunys
 */
public class userS {
    
    public int id;
    public String fname;
    public String lname;
    public String username;
    public String pass;


    public userS() {
    }

    public userS(int id, String fname, String lname, String username, String pass) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.username = username;
        this.pass = pass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    
    ArrayList<userS> userList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
