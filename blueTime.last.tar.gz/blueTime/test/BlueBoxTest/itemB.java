package BlueBoxTest;

/**
 *
 * @author Developer Khaled Almunys
 */
public class itemB {
    private int ID;
    private String kind;
    private String item;
    private String types;
    private String brand;

    public itemB(int ID, String kind, String item, String types, String brand) {
        this.ID = ID;
        this.kind = kind;
        this.item = item;
        this.types = types;
        this.brand = brand;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getTypes() {
        return types;
    }

    public void setTypes(String types) {
        this.types = types;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
    
}
