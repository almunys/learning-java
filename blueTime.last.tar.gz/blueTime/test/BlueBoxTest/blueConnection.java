package BlueBoxTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Developer Khaled Almunys
 */
public class blueConnection {
    public  static Connection getConnected(){
        
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://swi.bluebox.com.kw/nccal_dB", "flooger", "nm901333");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
        return con;
    }
}
