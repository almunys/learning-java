-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 03, 2022 at 09:16 PM
-- Server version: 10.1.26-MariaDB-0+deb9u1
-- PHP Version: 7.0.33-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blue_dB`
--

-- --------------------------------------------------------

--
-- Table structure for table `main_repo`
--

CREATE TABLE `main_repo` (
  `iD` int(11) NOT NULL,
  `item` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_in` date NOT NULL,
  `date_out` date NOT NULL,
  `user_local` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `execution_date` date NOT NULL,
  `end_user_audio` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `end_user_light` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `end_user_video` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `end_user_reging` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `end_user_general` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `end_user_E_elecrission` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `end_user_E_events` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `itemsA` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `initial_ticket_text` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `report_action` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `local_reeport` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `main_repo`
--

INSERT INTO `main_repo` (`iD`, `item`, `location`, `entry_date`, `date_in`, `date_out`, `user_local`, `execution_date`, `end_user_audio`, `end_user_light`, `end_user_video`, `end_user_reging`, `end_user_general`, `end_user_E_elecrission`, `end_user_E_events`, `itemsA`, `initial_ticket_text`, `report_action`, `local_reeport`) VALUES
(1, 'Okk', 'النزهة', '2022-01-01 18:01:00', '2021-09-08', '2021-09-15', 'مهندس خالد', '2021-09-13', 'محمد', 'سعد', 'فهد', 'احمد', 'يوسف', 'علي', 'حسين', '', '998908 هذة تجربة الاولى', '', ''),
(2, 'OOKsdj', 'kuwait', '2021-10-01 21:29:13', '2021-10-05', '2021-10-30', 'kahled', '2021-10-21', 'me', 'me', 'me', 'me', 'me', 'me', 'me', '', 'klkaskdjhb,kwansdfblaskdhcvluiwsij', 'aklsjdhfliasjdhfliasjdhf', 'lkasjdhflkqsjdhgflksajhdgflasd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `main_repo`
--
ALTER TABLE `main_repo`
  ADD PRIMARY KEY (`iD`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `main_repo`
--
ALTER TABLE `main_repo`
  MODIFY `iD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
