-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 17, 2022 at 10:32 PM
-- Server version: 10.1.26-MariaDB-0+deb9u1
-- PHP Version: 7.0.33-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blue_dB`
--

-- --------------------------------------------------------

--
-- Table structure for table `Ev`
--

CREATE TABLE `Ev` (
  `iD` int(11) NOT NULL,
  `Event` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `e_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_in` date NOT NULL,
  `date_out` date NOT NULL,
  `L_user` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `audio` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `light` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `video` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `rigg` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `electric` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `addediTems` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Details` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `report` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `L_report` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Ev`
--

INSERT INTO `Ev` (`iD`, `Event`, `location`, `e_date`, `date_in`, `date_out`, `L_user`, `audio`, `light`, `video`, `rigg`, `electric`, `addediTems`, `Details`, `report`, `L_report`) VALUES
(1, 'event22', 'here', '2022-03-11 17:41:22', '2022-03-07', '2022-03-17', 'khaled', 'me', 'light', 'video', 'rigg', 'electric', 'mic\r\n7 speackers\r\n5 stands', 'a test event for the ..', '', ''),
(2, 'kokko', 'fahiha', '2022-03-17 18:13:50', '2022-03-01', '2022-03-02', '', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Ev`
--
ALTER TABLE `Ev`
  ADD PRIMARY KEY (`iD`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Ev`
--
ALTER TABLE `Ev`
  MODIFY `iD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
